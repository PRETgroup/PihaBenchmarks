function roots = numSolverQx(value,xi,xe,xc,yi,ye,yc,zi,ze,zc)  % add necessary inputs and outputs
    % xk=xi+xc/xe;
    % yk=yi+yc/ye;
    % zk=zi+zc/ze;
    % solve 0 = xk * exp(xe*t) - (xc/xe)
    %             - yk * exp(ye*t) + (yc/ye)
    %             + zk * exp(ze*t) - (zc/ze)
    %             -value
    % solve for t.
    test = 1.0000;
    digits(30);
    syms t;
    xk=xi+xc/xe;
    yk=yi+yc/ye;
    zk=zi+zc/ze;
    %equ=35.31*exp(-0.00332*t)-2.72*exp(0.280*t)+102.30*exp(0.0020*t)-30;
    fprintf('input: value %f, xi %f, xe %f, xc %f, yi %f, ye %f, yc %f, zi %f, ze %f, zc %f.\n',value,xi,xe,xc,yi,ye,yc,zi,ze,zc);
    fprintf('temp: xk %f, yk %f, zk %f.\n',xk,yk,zk);
    equ=xk*exp(xe*t)-(xc/xe)-yk*exp(ye*t)+(yc/ye)+zk*exp(ze*t)-(zc/ze)-value;
    temp=vpasolve(equ,t);
    temp2=0;
    temp2=double(temp(1));
    fprintf('time temp %f\n',temp2);
    roots=temp2;
end