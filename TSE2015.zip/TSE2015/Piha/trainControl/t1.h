#ifndef PROJECT__T1__H
#define PROJECT__T1__H
double t1_ode_1(double C1v, double d, double k);
double t1_ode_2(double C1v, double C1z, double d, double k);
double t1_init_1(double v_u);
double t1_init_2(double z_u);
#endif
