#ifndef PROJECT__T2__H
#define PROJECT__T2__H
double t2_ode_1(double C1v, double d, double k);
double t2_ode_2(double C1v, double C1z, double d, double k);
double t2_init_1(double v_u);
double t2_init_2(double z_u);
#endif
