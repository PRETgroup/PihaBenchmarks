#include<stdint.h>

#include<stdlib.h>

#include<stdio.h>

#define True 1

#define False 0

// Global variables from outside this HA

// Global variables in this HA

//Events

extern void readInput();

extern void writeOutput();

//Continous variables

double z, v;

//Continous variable update

double v_u, z_u;

//Continous variable init

double z_init, v_init;

//The constant variable

double C1z, C1v;

//Step-size constant d

extern double d;

//Nstep constant k

double k;

//States

enum states {t1 , t2};

//Previous state variable

#include "t1.h"
#include <math.h>
double t1_ode_1(double C1v, double d, double k) {
   double t1_ode_1_result;
   t1_ode_1_result = C1v + 5*d*k;
   return t1_ode_1_result;
}
double t1_ode_2(double C1v, double C1z, double d, double k) {
   double t1_ode_2_result;
   t1_ode_2_result = C1v*d*k + C1z + (5.0L/2.0L)*pow(d, 2)*pow(k, 2);
   return t1_ode_2_result;
}
double t1_init_1(double v_u) {
   double t1_init_1_result;
   t1_init_1_result = v_u;
   return t1_init_1_result;
}
double t1_init_2(double z_u) {
   double t1_init_2_result;
   t1_init_2_result = z_u;
   return t1_init_2_result;
}


#include "t2.h"
#include <math.h>
double t2_ode_1(double C1v, double d, double k) {
   double t2_ode_1_result;
   t2_ode_1_result = C1v - 10*d*k;
   return t2_ode_1_result;
}
double t2_ode_2(double C1v, double C1z, double d, double k) {
   double t2_ode_2_result;
   t2_ode_2_result = C1v*d*k + C1z - 5*pow(d, 2)*pow(k, 2);
   return t2_ode_2_result;
}
double t2_init_1(double v_u) {
   double t2_init_1_result;
   t2_init_1_result = v_u;
   return t2_init_1_result;
}
double t2_init_2(double z_u) {
   double t2_init_2_result;
   t2_init_2_result = z_u;
   return t2_init_2_result;
}


enum states train_control(enum states cstate, enum states pstate) {
  static double fk;
  static unsigned char force_init_update;
  switch (cstate) {
  case (t1):
    if(z >= 0 && v >= 0 && v < 1000){
      if ((pstate != cstate) || force_init_update){
        C1v = t1_init_1(v);
        v_init = v;
      }
      v_u = t1_ode_1(C1v, d, k);
      if(v_u > 1000 && v_init <= 1000)
        v_u = 1000;
      if ((pstate != cstate) || force_init_update){
        C1z = t1_init_2(z);
        z_init = z;
      }
      z_u = t1_ode_2(C1v, C1z, d, k);
      if(z_u > 0 && z_init <= 0)
        z_u = 0;
      if(z_u < 0 && z_init >= 0)
        z_u = 0;
      ++k;
      cstate = t1;
      force_init_update = False;
    }
    else if(True && v >= 1000) {
      k=1;
      cstate=t2;
      z_u = z;
      v_u = v;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (t2):
    if(z >= 0 && v > 20){
      if ((pstate != cstate) || force_init_update){
        C1v = t2_init_1(v);
        v_init = v;
      }
      v_u = t2_ode_1(C1v, d, k);
      if(v_u < 20 && v_init >= 20)
        v_u = 20;
      if ((pstate != cstate) || force_init_update){
        C1z = t2_init_2(z);
        z_init = z;
      }
      z_u = t2_ode_2(C1v, C1z, d, k);
      if(z_u > 0 && z_init <= 0)
        z_u = 0;
      if(z_u < 0 && z_init >= 0)
        z_u = 0;
      ++k;
      cstate = t2;
      force_init_update = False;
    }
    else if(True && v <= 20) {
      k=1;
      cstate=t1;
      z_u = z;
      v_u = v;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  default: exit(1);
  }
  return cstate;
}

int main(void) {
  v = 0;
  z = 0;
  enum states pstate = -1;
  enum states cstate = t1;
  while(True) {
    readInput();
    enum states rstate = train_control(cstate, pstate);
    pstate = cstate;
    cstate = rstate;
    z = z_u;
    v = v_u;
    writeOutput();
  }
  return 0;
}