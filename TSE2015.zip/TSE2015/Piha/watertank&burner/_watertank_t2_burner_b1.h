#ifndef PROJECT___WATERTANK_T2_BURNER_B1__H
#define PROJECT___WATERTANK_T2_BURNER_B1__H
double _watertank_t2_burner_b1_ode_1(double C1x);
double _watertank_t2_burner_b1_ode_2(double C1y);
double _watertank_t2_burner_b1_init_1(double x_u);
double _watertank_t2_burner_b1_init_2(double y_u);
#endif
