#ifndef PROJECT___WATERTANK_T1_BURNER_B2__H
#define PROJECT___WATERTANK_T1_BURNER_B2__H
double _watertank_t1_burner_b2_ode_1(double C1x, double d, double k);
double _watertank_t1_burner_b2_ode_2(double C1y, double d, double k);
double _watertank_t1_burner_b2_init_1(double x_u);
double _watertank_t1_burner_b2_init_2(double y_u);
#endif
