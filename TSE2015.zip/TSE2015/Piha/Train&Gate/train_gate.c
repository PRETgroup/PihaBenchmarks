#include<stdint.h>

#include<stdlib.h>

#include<stdio.h>

#define True 1

#define False 0

// Global variables from outside this HA

// Global variables in this HA

//Events

extern unsigned char DOWN, UP;

extern void readInput();

extern void writeOutput();

//Continous variables

double y, x;

//Continous variable update

double y_u, x_u;

//Continous variable init

double y_init, x_init;

//The constant variable

double C1y, C1x;

//Step-size constant d

extern double d;

//Nstep constant k

double k;

//States

enum states {_train_t1_gate_t1 , _train_t1_gate_t2 , _train_t2_gate_t1 , _train_t2_gate_t2 , _train_t3_gate_t1 , _train_t3_gate_t2};

//Previous state variable

#include "_train_t1_gate_t1.h"
#include <math.h>
double _train_t1_gate_t1_ode_1(double C1y, double d, double k) {
   double _train_t1_gate_t1_ode_1_result;
   _train_t1_gate_t1_ode_1_result = C1y + d*k;
   return _train_t1_gate_t1_ode_1_result;
}
double _train_t1_gate_t1_ode_2(double C1x, double d, double k) {
   double _train_t1_gate_t1_ode_2_result;
   _train_t1_gate_t1_ode_2_result = C1x*exp(-1.0L/2.0L*d*k);
   return _train_t1_gate_t1_ode_2_result;
}
double _train_t1_gate_t1_init_1(double y_u) {
   double _train_t1_gate_t1_init_1_result;
   _train_t1_gate_t1_init_1_result = y_u;
   return _train_t1_gate_t1_init_1_result;
}
double _train_t1_gate_t1_init_2(double x_u) {
   double _train_t1_gate_t1_init_2_result;
   _train_t1_gate_t1_init_2_result = x_u;
   return _train_t1_gate_t1_init_2_result;
}


#include "_train_t1_gate_t2.h"
#include <math.h>
double _train_t1_gate_t2_ode_1(double C1y, double d, double k) {
   double _train_t1_gate_t2_ode_1_result;
   _train_t1_gate_t2_ode_1_result = C1y + d*k;
   return _train_t1_gate_t2_ode_1_result;
}
double _train_t1_gate_t2_ode_2(double C1x, double d, double k) {
   double _train_t1_gate_t2_ode_2_result;
   _train_t1_gate_t2_ode_2_result = C1x*exp(-1.0L/2.0L*d*k) + 11;
   return _train_t1_gate_t2_ode_2_result;
}
double _train_t1_gate_t2_init_1(double y_u) {
   double _train_t1_gate_t2_init_1_result;
   _train_t1_gate_t2_init_1_result = y_u;
   return _train_t1_gate_t2_init_1_result;
}
double _train_t1_gate_t2_init_2(double x_u) {
   double _train_t1_gate_t2_init_2_result;
   _train_t1_gate_t2_init_2_result = x_u - 11;
   return _train_t1_gate_t2_init_2_result;
}


#include "_train_t2_gate_t1.h"
#include <math.h>
double _train_t2_gate_t1_ode_1(double C1y, double d, double k) {
   double _train_t2_gate_t1_ode_1_result;
   _train_t2_gate_t1_ode_1_result = C1y + d*k;
   return _train_t2_gate_t1_ode_1_result;
}
double _train_t2_gate_t1_ode_2(double C1x, double d, double k) {
   double _train_t2_gate_t1_ode_2_result;
   _train_t2_gate_t1_ode_2_result = C1x*exp(-1.0L/2.0L*d*k);
   return _train_t2_gate_t1_ode_2_result;
}
double _train_t2_gate_t1_init_1(double y_u) {
   double _train_t2_gate_t1_init_1_result;
   _train_t2_gate_t1_init_1_result = y_u;
   return _train_t2_gate_t1_init_1_result;
}
double _train_t2_gate_t1_init_2(double x_u) {
   double _train_t2_gate_t1_init_2_result;
   _train_t2_gate_t1_init_2_result = x_u;
   return _train_t2_gate_t1_init_2_result;
}


#include "_train_t2_gate_t2.h"
#include <math.h>
double _train_t2_gate_t2_ode_1(double C1y, double d, double k) {
   double _train_t2_gate_t2_ode_1_result;
   _train_t2_gate_t2_ode_1_result = C1y + d*k;
   return _train_t2_gate_t2_ode_1_result;
}
double _train_t2_gate_t2_ode_2(double C1x, double d, double k) {
   double _train_t2_gate_t2_ode_2_result;
   _train_t2_gate_t2_ode_2_result = C1x*exp(-1.0L/2.0L*d*k) + 11;
   return _train_t2_gate_t2_ode_2_result;
}
double _train_t2_gate_t2_init_1(double y_u) {
   double _train_t2_gate_t2_init_1_result;
   _train_t2_gate_t2_init_1_result = y_u;
   return _train_t2_gate_t2_init_1_result;
}
double _train_t2_gate_t2_init_2(double x_u) {
   double _train_t2_gate_t2_init_2_result;
   _train_t2_gate_t2_init_2_result = x_u - 11;
   return _train_t2_gate_t2_init_2_result;
}


#include "_train_t3_gate_t1.h"
#include <math.h>
double _train_t3_gate_t1_ode_1(double C1y, double d, double k) {
   double _train_t3_gate_t1_ode_1_result;
   _train_t3_gate_t1_ode_1_result = C1y + d*k;
   return _train_t3_gate_t1_ode_1_result;
}
double _train_t3_gate_t1_ode_2(double C1x, double d, double k) {
   double _train_t3_gate_t1_ode_2_result;
   _train_t3_gate_t1_ode_2_result = C1x*exp(-1.0L/2.0L*d*k);
   return _train_t3_gate_t1_ode_2_result;
}
double _train_t3_gate_t1_init_1(double y_u) {
   double _train_t3_gate_t1_init_1_result;
   _train_t3_gate_t1_init_1_result = y_u;
   return _train_t3_gate_t1_init_1_result;
}
double _train_t3_gate_t1_init_2(double x_u) {
   double _train_t3_gate_t1_init_2_result;
   _train_t3_gate_t1_init_2_result = x_u;
   return _train_t3_gate_t1_init_2_result;
}


#include "_train_t3_gate_t2.h"
#include <math.h>
double _train_t3_gate_t2_ode_1(double C1y, double d, double k) {
   double _train_t3_gate_t2_ode_1_result;
   _train_t3_gate_t2_ode_1_result = C1y + d*k;
   return _train_t3_gate_t2_ode_1_result;
}
double _train_t3_gate_t2_ode_2(double C1x, double d, double k) {
   double _train_t3_gate_t2_ode_2_result;
   _train_t3_gate_t2_ode_2_result = C1x*exp(-1.0L/2.0L*d*k) + 11;
   return _train_t3_gate_t2_ode_2_result;
}
double _train_t3_gate_t2_init_1(double y_u) {
   double _train_t3_gate_t2_init_1_result;
   _train_t3_gate_t2_init_1_result = y_u;
   return _train_t3_gate_t2_init_1_result;
}
double _train_t3_gate_t2_init_2(double x_u) {
   double _train_t3_gate_t2_init_2_result;
   _train_t3_gate_t2_init_2_result = x_u - 11;
   return _train_t3_gate_t2_init_2_result;
}


enum states train_gate(enum states cstate, enum states pstate) {
  static double fk;
  static unsigned char force_init_update;
  switch (cstate) {
  case (_train_t1_gate_t1):
    if(y < 5 && x >= 1 && x <= 10 && !DOWN && !UP){
      if ((pstate != cstate) || force_init_update){
        C1y = _train_t1_gate_t1_init_1(y);
        y_init = y;
      }
      y_u = _train_t1_gate_t1_ode_1(C1y, d, k);
      if(y_u > 5 && y_init <= 5)
        y_u = 5;
      if ((pstate != cstate) || force_init_update){
        C1x = _train_t1_gate_t1_init_2(x);
        x_init = x;
      }
      x_u = _train_t1_gate_t1_ode_2(C1x, d, k);
      if(x_u < 1 && x_init >= 1)
        x_u = 1;
      ++k;
      cstate = _train_t1_gate_t1;
      force_init_update = False;
    }
    else if(UP && y >= 5 && y <= 5 && True && True) {
      k=1;
      cstate=_train_t2_gate_t2;
      y_u = y;
      signal_u =1;
      x_u = x;
    }
    else if(UP && True) {
      k=1;
      cstate=_train_t1_gate_t2;
      x_u = x;
      y_u = y;
      x_u = x;
      y_u = y;
    }
    else if(True && y >= 5 && y <= 5 && True && True) {
      k=1;
      cstate=_train_t2_gate_t1;
      y_u = y;
      signal_u =1;
      x_u = x;
      x_u = x;
      y_u = y;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (_train_t1_gate_t2):
    if(y < 5 && x >= 1 && x <= 10 && !DOWN && !UP){
      if ((pstate != cstate) || force_init_update){
        C1y = _train_t1_gate_t2_init_1(y);
        y_init = y;
      }
      y_u = _train_t1_gate_t2_ode_1(C1y, d, k);
      if(y_u > 5 && y_init <= 5)
        y_u = 5;
      if ((pstate != cstate) || force_init_update){
        C1x = _train_t1_gate_t2_init_2(x);
        x_init = x;
      }
      x_u = _train_t1_gate_t2_ode_2(C1x, d, k);
      if(x_u > 10 && x_init <= 10)
        x_u = 10;
      ++k;
      cstate = _train_t1_gate_t2;
      force_init_update = False;
    }
    else if(DOWN && y >= 5 && y <= 5 && True && True) {
      k=1;
      cstate=_train_t2_gate_t1;
      y_u = y;
      signal_u =1;
      x_u = x;
    }
    else if(DOWN && True) {
      k=1;
      cstate=_train_t1_gate_t1;
      x_u = x;
      y_u = y;
      x_u = x;
      y_u = y;
    }
    else if(True && y >= 5 && y <= 5 && True && True) {
      k=1;
      cstate=_train_t2_gate_t2;
      y_u = y;
      signal_u =1;
      x_u = x;
      x_u = x;
      y_u = y;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (_train_t2_gate_t1):
    if(y >= 5 && y < 15 && x >= 1 && x <= 10 && !DOWN && !UP){
      if ((pstate != cstate) || force_init_update){
        C1y = _train_t2_gate_t1_init_1(y);
        y_init = y;
      }
      y_u = _train_t2_gate_t1_ode_1(C1y, d, k);
      if(y_u > 15 && y_init <= 15)
        y_u = 15;
      if ((pstate != cstate) || force_init_update){
        C1x = _train_t2_gate_t1_init_2(x);
        x_init = x;
      }
      x_u = _train_t2_gate_t1_ode_2(C1x, d, k);
      if(x_u < 1 && x_init >= 1)
        x_u = 1;
      ++k;
      cstate = _train_t2_gate_t1;
      force_init_update = False;
    }
    else if(UP && y >= 15 && y <= 15 && True && True) {
      k=1;
      cstate=_train_t3_gate_t2;
      y_u = y;
      signal_u =0;
      x_u = x;
    }
    else if(UP && True) {
      k=1;
      cstate=_train_t2_gate_t2;
      x_u = x;
      y_u = y;
      x_u = x;
      y_u = y;
    }
    else if(True && y >= 15 && y <= 15 && True && True) {
      k=1;
      cstate=_train_t3_gate_t1;
      y_u = y;
      signal_u =0;
      x_u = x;
      x_u = x;
      y_u = y;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (_train_t2_gate_t2):
    if(y >= 5 && y < 15 && x >= 1 && x <= 10 && !DOWN && !UP){
      if ((pstate != cstate) || force_init_update){
        C1y = _train_t2_gate_t2_init_1(y);
        y_init = y;
      }
      y_u = _train_t2_gate_t2_ode_1(C1y, d, k);
      if(y_u > 15 && y_init <= 15)
        y_u = 15;
      if ((pstate != cstate) || force_init_update){
        C1x = _train_t2_gate_t2_init_2(x);
        x_init = x;
      }
      x_u = _train_t2_gate_t2_ode_2(C1x, d, k);
      if(x_u > 10 && x_init <= 10)
        x_u = 10;
      ++k;
      cstate = _train_t2_gate_t2;
      force_init_update = False;
    }
    else if(DOWN && y >= 15 && y <= 15 && True && True) {
      k=1;
      cstate=_train_t3_gate_t1;
      y_u = y;
      signal_u =0;
      x_u = x;
    }
    else if(DOWN && True) {
      k=1;
      cstate=_train_t2_gate_t1;
      x_u = x;
      y_u = y;
      x_u = x;
      y_u = y;
    }
    else if(True && y >= 15 && y <= 15 && True && True) {
      k=1;
      cstate=_train_t3_gate_t2;
      y_u = y;
      signal_u =0;
      x_u = x;
      x_u = x;
      y_u = y;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (_train_t3_gate_t1):
    if(y >= 15 && y < 25 && x >= 1 && x <= 10 && !DOWN && !UP){
      if ((pstate != cstate) || force_init_update){
        C1y = _train_t3_gate_t1_init_1(y);
        y_init = y;
      }
      y_u = _train_t3_gate_t1_ode_1(C1y, d, k);
      if(y_u > 25 && y_init <= 25)
        y_u = 25;
      if ((pstate != cstate) || force_init_update){
        C1x = _train_t3_gate_t1_init_2(x);
        x_init = x;
      }
      x_u = _train_t3_gate_t1_ode_2(C1x, d, k);
      if(x_u < 1 && x_init >= 1)
        x_u = 1;
      ++k;
      cstate = _train_t3_gate_t1;
      force_init_update = False;
    }
    else if(UP && y >= 25 && y <= 25 && True && True) {
      k=1;
      cstate=_train_t1_gate_t2;
      y_u =0;
      x_u = x;
    }
    else if(True && y >= 25 && y <= 25 && True && True) {
      k=1;
      cstate=_train_t1_gate_t1;
      y_u =0;
      x_u = x;
      x_u = x;
    }
    else if(UP && True) {
      k=1;
      cstate=_train_t3_gate_t2;
      x_u = x;
      x_u = x;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (_train_t3_gate_t2):
    if(y >= 15 && y < 25 && x >= 1 && x <= 10 && !DOWN && !UP){
      if ((pstate != cstate) || force_init_update){
        C1y = _train_t3_gate_t2_init_1(y);
        y_init = y;
      }
      y_u = _train_t3_gate_t2_ode_1(C1y, d, k);
      if(y_u > 25 && y_init <= 25)
        y_u = 25;
      if ((pstate != cstate) || force_init_update){
        C1x = _train_t3_gate_t2_init_2(x);
        x_init = x;
      }
      x_u = _train_t3_gate_t2_ode_2(C1x, d, k);
      if(x_u > 10 && x_init <= 10)
        x_u = 10;
      ++k;
      cstate = _train_t3_gate_t2;
      force_init_update = False;
    }
    else if(DOWN && y >= 25 && y <= 25 && True && True) {
      k=1;
      cstate=_train_t1_gate_t1;
      y_u =0;
      x_u = x;
    }
    else if(True && y >= 25 && y <= 25 && True && True) {
      k=1;
      cstate=_train_t1_gate_t2;
      y_u =0;
      x_u = x;
      x_u = x;
    }
    else if(DOWN && True) {
      k=1;
      cstate=_train_t3_gate_t1;
      x_u = x;
      x_u = x;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  default: exit(1);
  }
  return cstate;
}

int main(void) {
  y = 0;
  x = 1;
  enum states pstate = -1;
  enum states cstate = _train_t1_gate_t2;
  while(True) {
    readInput();
    enum states rstate = train_gate(cstate, pstate);
    pstate = cstate;
    cstate = rstate;
    y = y_u;
    x = x_u;
    writeOutput();
  }
  return 0;
}