#ifndef PROJECT___TRAIN_T2_GATE_T1__H
#define PROJECT___TRAIN_T2_GATE_T1__H
double _train_t2_gate_t1_ode_1(double C1y, double d, double k);
double _train_t2_gate_t1_ode_2(double C1x, double d, double k);
double _train_t2_gate_t1_init_1(double y_u);
double _train_t2_gate_t1_init_2(double x_u);
#endif
