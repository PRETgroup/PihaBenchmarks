#include<stdint.h>

#include<stdlib.h>

#include<stdio.h>

#define True 1

#define False 0

// Global variables from outside this HA

// Global variables in this HA

double signal_u;

//Events

extern unsigned char remove2, remove1, add1, add2;

extern void readInput();

extern void writeOutput();

//Continous variables

double x, ty1, ty2;

//Continous variable update

double ty2_u, x_u, ty1_u;

//Continous variable init

double ty1_init, ty2_init, x_init;

//The constant variable

double C1ty2, C1ty1, C1x;

//Step-size constant d

extern double d;

//Nstep constant k

double k;

//States

enum states {_controller_t0_plant_t0 , _controller_t0_plant_t1 , _controller_t0_plant_t2 , _controller_t1_plant_t0 , _controller_t1_plant_t1 , _controller_t1_plant_t2 , _controller_t2_plant_t0 , _controller_t2_plant_t1 , _controller_t2_plant_t2};

//Previous state variable

#include "_controller_t0_plant_t0.h"
#include <math.h>
double _controller_t0_plant_t0_ode_1(double C1ty1, double d, double k) {
   double _controller_t0_plant_t0_ode_1_result;
   _controller_t0_plant_t0_ode_1_result = C1ty1 + d*k;
   return _controller_t0_plant_t0_ode_1_result;
}
double _controller_t0_plant_t0_ode_2(double C1ty2, double d, double k) {
   double _controller_t0_plant_t0_ode_2_result;
   _controller_t0_plant_t0_ode_2_result = C1ty2 + d*k;
   return _controller_t0_plant_t0_ode_2_result;
}
double _controller_t0_plant_t0_ode_3(double C1x, double d, double k) {
   double _controller_t0_plant_t0_ode_3_result;
   _controller_t0_plant_t0_ode_3_result = C1x*exp(0.1*d*k) + 500.0;
   return _controller_t0_plant_t0_ode_3_result;
}
double _controller_t0_plant_t0_init_1(double ty1_u) {
   double _controller_t0_plant_t0_init_1_result;
   _controller_t0_plant_t0_init_1_result = ty1_u;
   return _controller_t0_plant_t0_init_1_result;
}
double _controller_t0_plant_t0_init_2(double ty2_u) {
   double _controller_t0_plant_t0_init_2_result;
   _controller_t0_plant_t0_init_2_result = ty2_u;
   return _controller_t0_plant_t0_init_2_result;
}
double _controller_t0_plant_t0_init_3(double x_u) {
   double _controller_t0_plant_t0_init_3_result;
   _controller_t0_plant_t0_init_3_result = x_u - 500.0;
   return _controller_t0_plant_t0_init_3_result;
}


#include "_controller_t0_plant_t1.h"
#include <math.h>
double _controller_t0_plant_t1_ode_1(double C1ty1, double d, double k) {
   double _controller_t0_plant_t1_ode_1_result;
   _controller_t0_plant_t1_ode_1_result = C1ty1 + d*k;
   return _controller_t0_plant_t1_ode_1_result;
}
double _controller_t0_plant_t1_ode_2(double C1ty2, double d, double k) {
   double _controller_t0_plant_t1_ode_2_result;
   _controller_t0_plant_t1_ode_2_result = C1ty2 + d*k;
   return _controller_t0_plant_t1_ode_2_result;
}
double _controller_t0_plant_t1_ode_3(double C1x, double d, double k) {
   double _controller_t0_plant_t1_ode_3_result;
   _controller_t0_plant_t1_ode_3_result = C1x*exp(0.1*d*k) + 560.0;
   return _controller_t0_plant_t1_ode_3_result;
}
double _controller_t0_plant_t1_init_1(double ty1_u) {
   double _controller_t0_plant_t1_init_1_result;
   _controller_t0_plant_t1_init_1_result = ty1_u;
   return _controller_t0_plant_t1_init_1_result;
}
double _controller_t0_plant_t1_init_2(double ty2_u) {
   double _controller_t0_plant_t1_init_2_result;
   _controller_t0_plant_t1_init_2_result = ty2_u;
   return _controller_t0_plant_t1_init_2_result;
}
double _controller_t0_plant_t1_init_3(double x_u) {
   double _controller_t0_plant_t1_init_3_result;
   _controller_t0_plant_t1_init_3_result = x_u - 560.0;
   return _controller_t0_plant_t1_init_3_result;
}


#include "_controller_t0_plant_t2.h"
#include <math.h>
double _controller_t0_plant_t2_ode_1(double C1ty1, double d, double k) {
   double _controller_t0_plant_t2_ode_1_result;
   _controller_t0_plant_t2_ode_1_result = C1ty1 + d*k;
   return _controller_t0_plant_t2_ode_1_result;
}
double _controller_t0_plant_t2_ode_2(double C1ty2, double d, double k) {
   double _controller_t0_plant_t2_ode_2_result;
   _controller_t0_plant_t2_ode_2_result = C1ty2 + d*k;
   return _controller_t0_plant_t2_ode_2_result;
}
double _controller_t0_plant_t2_ode_3(double C1x, double d, double k) {
   double _controller_t0_plant_t2_ode_3_result;
   _controller_t0_plant_t2_ode_3_result = C1x*exp(0.1*d*k) + 600.0;
   return _controller_t0_plant_t2_ode_3_result;
}
double _controller_t0_plant_t2_init_1(double ty1_u) {
   double _controller_t0_plant_t2_init_1_result;
   _controller_t0_plant_t2_init_1_result = ty1_u;
   return _controller_t0_plant_t2_init_1_result;
}
double _controller_t0_plant_t2_init_2(double ty2_u) {
   double _controller_t0_plant_t2_init_2_result;
   _controller_t0_plant_t2_init_2_result = ty2_u;
   return _controller_t0_plant_t2_init_2_result;
}
double _controller_t0_plant_t2_init_3(double x_u) {
   double _controller_t0_plant_t2_init_3_result;
   _controller_t0_plant_t2_init_3_result = x_u - 600.0;
   return _controller_t0_plant_t2_init_3_result;
}


#include "_controller_t1_plant_t0.h"
#include <math.h>
double _controller_t1_plant_t0_ode_1(double C1ty1, double d, double k) {
   double _controller_t1_plant_t0_ode_1_result;
   _controller_t1_plant_t0_ode_1_result = C1ty1 + d*k;
   return _controller_t1_plant_t0_ode_1_result;
}
double _controller_t1_plant_t0_ode_2(double C1ty2, double d, double k) {
   double _controller_t1_plant_t0_ode_2_result;
   _controller_t1_plant_t0_ode_2_result = C1ty2 + d*k;
   return _controller_t1_plant_t0_ode_2_result;
}
double _controller_t1_plant_t0_ode_3(double C1x, double d, double k) {
   double _controller_t1_plant_t0_ode_3_result;
   _controller_t1_plant_t0_ode_3_result = C1x*exp(0.1*d*k) + 500.0;
   return _controller_t1_plant_t0_ode_3_result;
}
double _controller_t1_plant_t0_init_1(double ty1_u) {
   double _controller_t1_plant_t0_init_1_result;
   _controller_t1_plant_t0_init_1_result = ty1_u;
   return _controller_t1_plant_t0_init_1_result;
}
double _controller_t1_plant_t0_init_2(double ty2_u) {
   double _controller_t1_plant_t0_init_2_result;
   _controller_t1_plant_t0_init_2_result = ty2_u;
   return _controller_t1_plant_t0_init_2_result;
}
double _controller_t1_plant_t0_init_3(double x_u) {
   double _controller_t1_plant_t0_init_3_result;
   _controller_t1_plant_t0_init_3_result = x_u - 500.0;
   return _controller_t1_plant_t0_init_3_result;
}


#include "_controller_t1_plant_t1.h"
#include <math.h>
double _controller_t1_plant_t1_ode_1(double C1ty1, double d, double k) {
   double _controller_t1_plant_t1_ode_1_result;
   _controller_t1_plant_t1_ode_1_result = C1ty1 + d*k;
   return _controller_t1_plant_t1_ode_1_result;
}
double _controller_t1_plant_t1_ode_2(double C1ty2, double d, double k) {
   double _controller_t1_plant_t1_ode_2_result;
   _controller_t1_plant_t1_ode_2_result = C1ty2 + d*k;
   return _controller_t1_plant_t1_ode_2_result;
}
double _controller_t1_plant_t1_ode_3(double C1x, double d, double k) {
   double _controller_t1_plant_t1_ode_3_result;
   _controller_t1_plant_t1_ode_3_result = C1x*exp(0.1*d*k) + 560.0;
   return _controller_t1_plant_t1_ode_3_result;
}
double _controller_t1_plant_t1_init_1(double ty1_u) {
   double _controller_t1_plant_t1_init_1_result;
   _controller_t1_plant_t1_init_1_result = ty1_u;
   return _controller_t1_plant_t1_init_1_result;
}
double _controller_t1_plant_t1_init_2(double ty2_u) {
   double _controller_t1_plant_t1_init_2_result;
   _controller_t1_plant_t1_init_2_result = ty2_u;
   return _controller_t1_plant_t1_init_2_result;
}
double _controller_t1_plant_t1_init_3(double x_u) {
   double _controller_t1_plant_t1_init_3_result;
   _controller_t1_plant_t1_init_3_result = x_u - 560.0;
   return _controller_t1_plant_t1_init_3_result;
}


#include "_controller_t1_plant_t2.h"
#include <math.h>
double _controller_t1_plant_t2_ode_1(double C1ty1, double d, double k) {
   double _controller_t1_plant_t2_ode_1_result;
   _controller_t1_plant_t2_ode_1_result = C1ty1 + d*k;
   return _controller_t1_plant_t2_ode_1_result;
}
double _controller_t1_plant_t2_ode_2(double C1ty2, double d, double k) {
   double _controller_t1_plant_t2_ode_2_result;
   _controller_t1_plant_t2_ode_2_result = C1ty2 + d*k;
   return _controller_t1_plant_t2_ode_2_result;
}
double _controller_t1_plant_t2_ode_3(double C1x, double d, double k) {
   double _controller_t1_plant_t2_ode_3_result;
   _controller_t1_plant_t2_ode_3_result = C1x*exp(0.1*d*k) + 600.0;
   return _controller_t1_plant_t2_ode_3_result;
}
double _controller_t1_plant_t2_init_1(double ty1_u) {
   double _controller_t1_plant_t2_init_1_result;
   _controller_t1_plant_t2_init_1_result = ty1_u;
   return _controller_t1_plant_t2_init_1_result;
}
double _controller_t1_plant_t2_init_2(double ty2_u) {
   double _controller_t1_plant_t2_init_2_result;
   _controller_t1_plant_t2_init_2_result = ty2_u;
   return _controller_t1_plant_t2_init_2_result;
}
double _controller_t1_plant_t2_init_3(double x_u) {
   double _controller_t1_plant_t2_init_3_result;
   _controller_t1_plant_t2_init_3_result = x_u - 600.0;
   return _controller_t1_plant_t2_init_3_result;
}


#include "_controller_t2_plant_t0.h"
#include <math.h>
double _controller_t2_plant_t0_ode_1(double C1ty1, double d, double k) {
   double _controller_t2_plant_t0_ode_1_result;
   _controller_t2_plant_t0_ode_1_result = C1ty1 + d*k;
   return _controller_t2_plant_t0_ode_1_result;
}
double _controller_t2_plant_t0_ode_2(double C1ty2, double d, double k) {
   double _controller_t2_plant_t0_ode_2_result;
   _controller_t2_plant_t0_ode_2_result = C1ty2 + d*k;
   return _controller_t2_plant_t0_ode_2_result;
}
double _controller_t2_plant_t0_ode_3(double C1x, double d, double k) {
   double _controller_t2_plant_t0_ode_3_result;
   _controller_t2_plant_t0_ode_3_result = C1x*exp(0.1*d*k) + 500.0;
   return _controller_t2_plant_t0_ode_3_result;
}
double _controller_t2_plant_t0_init_1(double ty1_u) {
   double _controller_t2_plant_t0_init_1_result;
   _controller_t2_plant_t0_init_1_result = ty1_u;
   return _controller_t2_plant_t0_init_1_result;
}
double _controller_t2_plant_t0_init_2(double ty2_u) {
   double _controller_t2_plant_t0_init_2_result;
   _controller_t2_plant_t0_init_2_result = ty2_u;
   return _controller_t2_plant_t0_init_2_result;
}
double _controller_t2_plant_t0_init_3(double x_u) {
   double _controller_t2_plant_t0_init_3_result;
   _controller_t2_plant_t0_init_3_result = x_u - 500.0;
   return _controller_t2_plant_t0_init_3_result;
}


#include "_controller_t2_plant_t1.h"
#include <math.h>
double _controller_t2_plant_t1_ode_1(double C1ty1, double d, double k) {
   double _controller_t2_plant_t1_ode_1_result;
   _controller_t2_plant_t1_ode_1_result = C1ty1 + d*k;
   return _controller_t2_plant_t1_ode_1_result;
}
double _controller_t2_plant_t1_ode_2(double C1ty2, double d, double k) {
   double _controller_t2_plant_t1_ode_2_result;
   _controller_t2_plant_t1_ode_2_result = C1ty2 + d*k;
   return _controller_t2_plant_t1_ode_2_result;
}
double _controller_t2_plant_t1_ode_3(double C1x, double d, double k) {
   double _controller_t2_plant_t1_ode_3_result;
   _controller_t2_plant_t1_ode_3_result = C1x*exp(0.1*d*k) + 560.0;
   return _controller_t2_plant_t1_ode_3_result;
}
double _controller_t2_plant_t1_init_1(double ty1_u) {
   double _controller_t2_plant_t1_init_1_result;
   _controller_t2_plant_t1_init_1_result = ty1_u;
   return _controller_t2_plant_t1_init_1_result;
}
double _controller_t2_plant_t1_init_2(double ty2_u) {
   double _controller_t2_plant_t1_init_2_result;
   _controller_t2_plant_t1_init_2_result = ty2_u;
   return _controller_t2_plant_t1_init_2_result;
}
double _controller_t2_plant_t1_init_3(double x_u) {
   double _controller_t2_plant_t1_init_3_result;
   _controller_t2_plant_t1_init_3_result = x_u - 560.0;
   return _controller_t2_plant_t1_init_3_result;
}


#include "_controller_t2_plant_t2.h"
#include <math.h>
double _controller_t2_plant_t2_ode_1(double C1ty1, double d, double k) {
   double _controller_t2_plant_t2_ode_1_result;
   _controller_t2_plant_t2_ode_1_result = C1ty1 + d*k;
   return _controller_t2_plant_t2_ode_1_result;
}
double _controller_t2_plant_t2_ode_2(double C1ty2, double d, double k) {
   double _controller_t2_plant_t2_ode_2_result;
   _controller_t2_plant_t2_ode_2_result = C1ty2 + d*k;
   return _controller_t2_plant_t2_ode_2_result;
}
double _controller_t2_plant_t2_ode_3(double C1x, double d, double k) {
   double _controller_t2_plant_t2_ode_3_result;
   _controller_t2_plant_t2_ode_3_result = C1x*exp(0.1*d*k) + 600.0;
   return _controller_t2_plant_t2_ode_3_result;
}
double _controller_t2_plant_t2_init_1(double ty1_u) {
   double _controller_t2_plant_t2_init_1_result;
   _controller_t2_plant_t2_init_1_result = ty1_u;
   return _controller_t2_plant_t2_init_1_result;
}
double _controller_t2_plant_t2_init_2(double ty2_u) {
   double _controller_t2_plant_t2_init_2_result;
   _controller_t2_plant_t2_init_2_result = ty2_u;
   return _controller_t2_plant_t2_init_2_result;
}
double _controller_t2_plant_t2_init_3(double x_u) {
   double _controller_t2_plant_t2_init_3_result;
   _controller_t2_plant_t2_init_3_result = x_u - 600.0;
   return _controller_t2_plant_t2_init_3_result;
}


enum states controller_plant(enum states cstate, enum states pstate) {
  static double fk;
  static unsigned char force_init_update;
  switch (cstate) {
  case (_controller_t0_plant_t0):
    if(ty1 <= 100000 && ty2 <= 100000 && x < 550 && True && True && True && !remove2 && !remove1 && !add1 && !add2){
      if ((pstate != cstate) || force_init_update){
        C1ty1 = _controller_t0_plant_t0_init_1(ty1);
        ty1_init = ty1;
      }
      ty1_u = _controller_t0_plant_t0_ode_1(C1ty1, d, k);
      if(ty1_u > 100000 && ty1_init <= 100000)
        ty1_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1ty2 = _controller_t0_plant_t0_init_2(ty2);
        ty2_init = ty2;
      }
      ty2_u = _controller_t0_plant_t0_ode_2(C1ty2, d, k);
      if(ty2_u > 100000 && ty2_init <= 100000)
        ty2_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1x = _controller_t0_plant_t0_init_3(x);
        x_init = x;
      }
      x_u = _controller_t0_plant_t0_ode_3(C1x, d, k);
      if(x_u > 550 && x_init <= 550)
        x_u = 550;
      ++k;
      cstate = _controller_t0_plant_t0;
      force_init_update = False;
    }
    else if(add1 && ty2 < 10 && x >= 550 && True && True && True && True && ty1 >= 10) {
      k=1;
      cstate=_controller_t1_plant_t1;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =1;
      x_u = x;
    }
    else if(add2 && ty2 < 10 && x >= 550 && True && True && True && True && ty1 >= 10) {
      k=1;
      cstate=_controller_t1_plant_t2;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =1;
      x_u = x;
    }
    else if(add1 && ty2 >= 10 && x >= 550 && True && True && True && True) {
      k=1;
      cstate=_controller_t2_plant_t1;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =2;
      x_u = x;
    }
    else if(add2 && ty2 >= 10 && x >= 550 && True && True && True && True) {
      k=1;
      cstate=_controller_t2_plant_t2;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =2;
      x_u = x;
    }
    else if(add1 && True) {
      k=1;
      cstate=_controller_t0_plant_t1;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else if(True && ty1 >= 10 && ty2 < 10 && x >= 550 && True && True && True && True) {
      k=1;
      cstate=_controller_t1_plant_t0;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =1;
      x_u = x;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else if(add2 && True) {
      k=1;
      cstate=_controller_t0_plant_t2;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else if(True && ty1 >= 10 && ty2 < 10 && x >= 550 && True && True && True && True) {
      k=1;
      cstate=_controller_t1_plant_t0;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =1;
      x_u = x;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else if(True && ty2 >= 10 && x >= 550 && True && True && True && True) {
      k=1;
      cstate=_controller_t2_plant_t0;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =2;
      x_u = x;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else if(add1 && True) {
      k=1;
      cstate=_controller_t0_plant_t1;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else if(True && ty2 >= 10 && x >= 550 && True && True && True && True) {
      k=1;
      cstate=_controller_t2_plant_t0;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =2;
      x_u = x;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else if(add2 && True) {
      k=1;
      cstate=_controller_t0_plant_t2;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (_controller_t0_plant_t1):
    if(ty1 <= 100000 && ty2 <= 100000 && x < 550 && True && True && True && !remove2 && !remove1 && !add1 && !add2){
      if ((pstate != cstate) || force_init_update){
        C1ty1 = _controller_t0_plant_t1_init_1(ty1);
        ty1_init = ty1;
      }
      ty1_u = _controller_t0_plant_t1_ode_1(C1ty1, d, k);
      if(ty1_u > 100000 && ty1_init <= 100000)
        ty1_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1ty2 = _controller_t0_plant_t1_init_2(ty2);
        ty2_init = ty2;
      }
      ty2_u = _controller_t0_plant_t1_ode_2(C1ty2, d, k);
      if(ty2_u > 100000 && ty2_init <= 100000)
        ty2_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1x = _controller_t0_plant_t1_init_3(x);
        x_init = x;
      }
      x_u = _controller_t0_plant_t1_ode_3(C1x, d, k);
      if(x_u < 550 && x_init >= 550)
        x_u = 550;
      ++k;
      cstate = _controller_t0_plant_t1;
      force_init_update = False;
    }
    else if(remove1 && ty2 < 10 && x >= 550 && True && True && True && True && ty1 >= 10) {
      k=1;
      cstate=_controller_t1_plant_t0;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =1;
      x_u = x;
    }
    else if(remove1 && ty2 >= 10 && x >= 550 && True && True && True && True) {
      k=1;
      cstate=_controller_t2_plant_t0;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =2;
      x_u = x;
    }
    else if(remove1 && True) {
      k=1;
      cstate=_controller_t0_plant_t0;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else if(True && ty1 >= 10 && ty2 < 10 && x >= 550 && True && True && True && True) {
      k=1;
      cstate=_controller_t1_plant_t1;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =1;
      x_u = x;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else if(True && ty2 >= 10 && x >= 550 && True && True && True && True) {
      k=1;
      cstate=_controller_t2_plant_t1;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =2;
      x_u = x;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else if(remove1 && True) {
      k=1;
      cstate=_controller_t0_plant_t0;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (_controller_t0_plant_t2):
    if(ty1 <= 100000 && ty2 <= 100000 && x < 550 && True && True && True && !remove2 && !remove1 && !add1 && !add2){
      if ((pstate != cstate) || force_init_update){
        C1ty1 = _controller_t0_plant_t2_init_1(ty1);
        ty1_init = ty1;
      }
      ty1_u = _controller_t0_plant_t2_ode_1(C1ty1, d, k);
      if(ty1_u > 100000 && ty1_init <= 100000)
        ty1_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1ty2 = _controller_t0_plant_t2_init_2(ty2);
        ty2_init = ty2;
      }
      ty2_u = _controller_t0_plant_t2_ode_2(C1ty2, d, k);
      if(ty2_u > 100000 && ty2_init <= 100000)
        ty2_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1x = _controller_t0_plant_t2_init_3(x);
        x_init = x;
      }
      x_u = _controller_t0_plant_t2_ode_3(C1x, d, k);
      if(x_u < 550 && x_init >= 550)
        x_u = 550;
      ++k;
      cstate = _controller_t0_plant_t2;
      force_init_update = False;
    }
    else if(remove2 && ty2 < 10 && x >= 550 && True && True && True && True && ty1 >= 10) {
      k=1;
      cstate=_controller_t1_plant_t0;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =1;
      x_u = x;
    }
    else if(remove2 && ty2 >= 10 && x >= 550 && True && True && True && True) {
      k=1;
      cstate=_controller_t2_plant_t0;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =2;
      x_u = x;
    }
    else if(remove2 && True) {
      k=1;
      cstate=_controller_t0_plant_t0;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else if(True && ty1 >= 10 && ty2 < 10 && x >= 550 && True && True && True && True) {
      k=1;
      cstate=_controller_t1_plant_t2;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =1;
      x_u = x;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else if(True && ty2 >= 10 && x >= 550 && True && True && True && True) {
      k=1;
      cstate=_controller_t2_plant_t2;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      signal_u =2;
      x_u = x;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else if(remove2 && True) {
      k=1;
      cstate=_controller_t0_plant_t0;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      ty2_u = ty2;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (_controller_t1_plant_t0):
    if(ty1 <= 100000 && ty2 <= 100000 && x > 510 && True && True && True && !remove2 && !remove1 && !add1 && !add2){
      if ((pstate != cstate) || force_init_update){
        C1ty1 = _controller_t1_plant_t0_init_1(ty1);
        ty1_init = ty1;
      }
      ty1_u = _controller_t1_plant_t0_ode_1(C1ty1, d, k);
      if(ty1_u > 100000 && ty1_init <= 100000)
        ty1_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1ty2 = _controller_t1_plant_t0_init_2(ty2);
        ty2_init = ty2;
      }
      ty2_u = _controller_t1_plant_t0_ode_2(C1ty2, d, k);
      if(ty2_u > 100000 && ty2_init <= 100000)
        ty2_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1x = _controller_t1_plant_t0_init_3(x);
        x_init = x;
      }
      x_u = _controller_t1_plant_t0_ode_3(C1x, d, k);
      if(x_u > 510 && x_init <= 510)
        x_u = 510;
      ++k;
      cstate = _controller_t1_plant_t0;
      force_init_update = False;
    }
    else if(add1 && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t1;
      x_u = x;
      ty1_u =0;
      ty2_u = ty2;
      signal_u =0.1;
      x_u = x;
    }
    else if(add2 && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t2;
      x_u = x;
      ty1_u =0;
      ty2_u = ty2;
      signal_u =0.1;
      x_u = x;
    }
    else if(True && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t0;
      x_u = x;
      ty1_u =0;
      ty2_u = ty2;
      signal_u =0.1;
      x_u = x;
      x_u = x;
      x_u = x;
      ty2_u = ty2;
    }
    else if(add1 && True) {
      k=1;
      cstate=_controller_t1_plant_t1;
      x_u = x;
      x_u = x;
      ty2_u = ty2;
      x_u = x;
      x_u = x;
      ty2_u = ty2;
    }
    else if(True && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t0;
      x_u = x;
      ty1_u =0;
      ty2_u = ty2;
      signal_u =0.1;
      x_u = x;
      x_u = x;
      x_u = x;
      ty2_u = ty2;
    }
    else if(add2 && True) {
      k=1;
      cstate=_controller_t1_plant_t2;
      x_u = x;
      x_u = x;
      ty2_u = ty2;
      x_u = x;
      x_u = x;
      ty2_u = ty2;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (_controller_t1_plant_t1):
    if(ty1 <= 100000 && ty2 <= 100000 && x > 510 && True && True && True && !remove2 && !remove1 && !add1 && !add2){
      if ((pstate != cstate) || force_init_update){
        C1ty1 = _controller_t1_plant_t1_init_1(ty1);
        ty1_init = ty1;
      }
      ty1_u = _controller_t1_plant_t1_ode_1(C1ty1, d, k);
      if(ty1_u > 100000 && ty1_init <= 100000)
        ty1_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1ty2 = _controller_t1_plant_t1_init_2(ty2);
        ty2_init = ty2;
      }
      ty2_u = _controller_t1_plant_t1_ode_2(C1ty2, d, k);
      if(ty2_u > 100000 && ty2_init <= 100000)
        ty2_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1x = _controller_t1_plant_t1_init_3(x);
        x_init = x;
      }
      x_u = _controller_t1_plant_t1_ode_3(C1x, d, k);
      if(x_u < 510 && x_init >= 510)
        x_u = 510;
      ++k;
      cstate = _controller_t1_plant_t1;
      force_init_update = False;
    }
    else if(remove1 && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t0;
      x_u = x;
      ty1_u =0;
      ty2_u = ty2;
      signal_u =0.1;
      x_u = x;
    }
    else if(True && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t1;
      x_u = x;
      ty1_u =0;
      ty2_u = ty2;
      signal_u =0.1;
      x_u = x;
      x_u = x;
      x_u = x;
      ty2_u = ty2;
    }
    else if(remove1 && True) {
      k=1;
      cstate=_controller_t1_plant_t0;
      x_u = x;
      x_u = x;
      ty2_u = ty2;
      x_u = x;
      x_u = x;
      ty2_u = ty2;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (_controller_t1_plant_t2):
    if(ty1 <= 100000 && ty2 <= 100000 && x > 510 && True && True && True && !remove2 && !remove1 && !add1 && !add2){
      if ((pstate != cstate) || force_init_update){
        C1ty1 = _controller_t1_plant_t2_init_1(ty1);
        ty1_init = ty1;
      }
      ty1_u = _controller_t1_plant_t2_ode_1(C1ty1, d, k);
      if(ty1_u > 100000 && ty1_init <= 100000)
        ty1_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1ty2 = _controller_t1_plant_t2_init_2(ty2);
        ty2_init = ty2;
      }
      ty2_u = _controller_t1_plant_t2_ode_2(C1ty2, d, k);
      if(ty2_u > 100000 && ty2_init <= 100000)
        ty2_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1x = _controller_t1_plant_t2_init_3(x);
        x_init = x;
      }
      x_u = _controller_t1_plant_t2_ode_3(C1x, d, k);
      if(x_u < 510 && x_init >= 510)
        x_u = 510;
      ++k;
      cstate = _controller_t1_plant_t2;
      force_init_update = False;
    }
    else if(remove2 && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t0;
      x_u = x;
      ty1_u =0;
      ty2_u = ty2;
      signal_u =0.1;
      x_u = x;
    }
    else if(True && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t2;
      x_u = x;
      ty1_u =0;
      ty2_u = ty2;
      signal_u =0.1;
      x_u = x;
      x_u = x;
      x_u = x;
      ty2_u = ty2;
    }
    else if(remove2 && True) {
      k=1;
      cstate=_controller_t1_plant_t0;
      x_u = x;
      x_u = x;
      ty2_u = ty2;
      x_u = x;
      x_u = x;
      ty2_u = ty2;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (_controller_t2_plant_t0):
    if(ty1 <= 100000 && ty2 <= 100000 && x > 510 && True && True && True && !remove2 && !remove1 && !add1 && !add2){
      if ((pstate != cstate) || force_init_update){
        C1ty1 = _controller_t2_plant_t0_init_1(ty1);
        ty1_init = ty1;
      }
      ty1_u = _controller_t2_plant_t0_ode_1(C1ty1, d, k);
      if(ty1_u > 100000 && ty1_init <= 100000)
        ty1_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1ty2 = _controller_t2_plant_t0_init_2(ty2);
        ty2_init = ty2;
      }
      ty2_u = _controller_t2_plant_t0_ode_2(C1ty2, d, k);
      if(ty2_u > 100000 && ty2_init <= 100000)
        ty2_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1x = _controller_t2_plant_t0_init_3(x);
        x_init = x;
      }
      x_u = _controller_t2_plant_t0_ode_3(C1x, d, k);
      if(x_u > 510 && x_init <= 510)
        x_u = 510;
      ++k;
      cstate = _controller_t2_plant_t0;
      force_init_update = False;
    }
    else if(add1 && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t1;
      x_u = x;
      ty1_u = ty1;
      ty2_u =0;
      signal_u =0.2;
      x_u = x;
    }
    else if(add2 && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t2;
      x_u = x;
      ty1_u = ty1;
      ty2_u =0;
      signal_u =0.2;
      x_u = x;
    }
    else if(add1 && True) {
      k=1;
      cstate=_controller_t2_plant_t1;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
    }
    else if(True && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t0;
      x_u = x;
      ty1_u = ty1;
      ty2_u =0;
      signal_u =0.2;
      x_u = x;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
    }
    else if(add2 && True) {
      k=1;
      cstate=_controller_t2_plant_t2;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
    }
    else if(True && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t0;
      x_u = x;
      ty1_u = ty1;
      ty2_u =0;
      signal_u =0.2;
      x_u = x;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (_controller_t2_plant_t1):
    if(ty1 <= 100000 && ty2 <= 100000 && x > 510 && True && True && True && !remove2 && !remove1 && !add1 && !add2){
      if ((pstate != cstate) || force_init_update){
        C1ty1 = _controller_t2_plant_t1_init_1(ty1);
        ty1_init = ty1;
      }
      ty1_u = _controller_t2_plant_t1_ode_1(C1ty1, d, k);
      if(ty1_u > 100000 && ty1_init <= 100000)
        ty1_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1ty2 = _controller_t2_plant_t1_init_2(ty2);
        ty2_init = ty2;
      }
      ty2_u = _controller_t2_plant_t1_ode_2(C1ty2, d, k);
      if(ty2_u > 100000 && ty2_init <= 100000)
        ty2_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1x = _controller_t2_plant_t1_init_3(x);
        x_init = x;
      }
      x_u = _controller_t2_plant_t1_ode_3(C1x, d, k);
      if(x_u < 510 && x_init >= 510)
        x_u = 510;
      ++k;
      cstate = _controller_t2_plant_t1;
      force_init_update = False;
    }
    else if(remove1 && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t0;
      x_u = x;
      ty1_u = ty1;
      ty2_u =0;
      signal_u =0.2;
      x_u = x;
    }
    else if(remove1 && True) {
      k=1;
      cstate=_controller_t2_plant_t0;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
    }
    else if(True && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t1;
      x_u = x;
      ty1_u = ty1;
      ty2_u =0;
      signal_u =0.2;
      x_u = x;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (_controller_t2_plant_t2):
    if(ty1 <= 100000 && ty2 <= 100000 && x > 510 && True && True && True && !remove2 && !remove1 && !add1 && !add2){
      if ((pstate != cstate) || force_init_update){
        C1ty1 = _controller_t2_plant_t2_init_1(ty1);
        ty1_init = ty1;
      }
      ty1_u = _controller_t2_plant_t2_ode_1(C1ty1, d, k);
      if(ty1_u > 100000 && ty1_init <= 100000)
        ty1_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1ty2 = _controller_t2_plant_t2_init_2(ty2);
        ty2_init = ty2;
      }
      ty2_u = _controller_t2_plant_t2_ode_2(C1ty2, d, k);
      if(ty2_u > 100000 && ty2_init <= 100000)
        ty2_u = 100000;
      if ((pstate != cstate) || force_init_update){
        C1x = _controller_t2_plant_t2_init_3(x);
        x_init = x;
      }
      x_u = _controller_t2_plant_t2_ode_3(C1x, d, k);
      if(x_u < 510 && x_init >= 510)
        x_u = 510;
      ++k;
      cstate = _controller_t2_plant_t2;
      force_init_update = False;
    }
    else if(remove2 && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t0;
      x_u = x;
      ty1_u = ty1;
      ty2_u =0;
      signal_u =0.2;
      x_u = x;
    }
    else if(remove2 && True) {
      k=1;
      cstate=_controller_t2_plant_t0;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
    }
    else if(True && x <= 510 && True && True && True && True) {
      k=1;
      cstate=_controller_t0_plant_t2;
      x_u = x;
      ty1_u = ty1;
      ty2_u =0;
      signal_u =0.2;
      x_u = x;
      x_u = x;
      x_u = x;
      ty1_u = ty1;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  default: exit(1);
  }
  return cstate;
}

int main(void) {
  ty1 = 10;
  ty2 = 10;
  x = 510;
  enum states pstate = -1;
  enum states cstate = _controller_t0_plant_t0;
  while(True) {
    readInput();
    enum states rstate = controller_plant(cstate, pstate);
    pstate = cstate;
    cstate = rstate;
    x = x_u;
    ty1 = ty1_u;
    ty2 = ty2_u;
    writeOutput();
  }
  return 0;
}