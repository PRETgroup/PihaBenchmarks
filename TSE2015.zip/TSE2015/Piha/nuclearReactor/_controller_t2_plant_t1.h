#ifndef PROJECT___CONTROLLER_T2_PLANT_T1__H
#define PROJECT___CONTROLLER_T2_PLANT_T1__H
double _controller_t2_plant_t1_ode_1(double C1ty1, double d, double k);
double _controller_t2_plant_t1_ode_2(double C1ty2, double d, double k);
double _controller_t2_plant_t1_ode_3(double C1x, double d, double k);
double _controller_t2_plant_t1_init_1(double ty1_u);
double _controller_t2_plant_t1_init_2(double ty2_u);
double _controller_t2_plant_t1_init_3(double x_u);
#endif
