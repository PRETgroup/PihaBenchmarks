#ifndef PROJECT___CONTROLLER_T1_PLANT_T2__H
#define PROJECT___CONTROLLER_T1_PLANT_T2__H
double _controller_t1_plant_t2_ode_1(double C1ty1, double d, double k);
double _controller_t1_plant_t2_ode_2(double C1ty2, double d, double k);
double _controller_t1_plant_t2_ode_3(double C1x, double d, double k);
double _controller_t1_plant_t2_init_1(double ty1_u);
double _controller_t1_plant_t2_init_2(double ty2_u);
double _controller_t1_plant_t2_init_3(double x_u);
#endif
