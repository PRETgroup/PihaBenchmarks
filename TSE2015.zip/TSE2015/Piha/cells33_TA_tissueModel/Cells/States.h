#ifndef CELL_STATES_H
#define CELL_STATES_H

// States
enum cellStates {REST, COND, ERP, RRP};


#endif
