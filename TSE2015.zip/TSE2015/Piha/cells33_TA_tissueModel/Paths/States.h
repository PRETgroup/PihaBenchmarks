#ifndef PATH_STATES_H
#define PATH_STATES_H

// States
enum pathStates {IDLE, ACT};

#endif
