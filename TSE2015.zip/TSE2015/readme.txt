This folder contains a set of hybrid automata examples
implemented in Simulink and Piha.
Piha is tool developed at University of Auckland, New Zealand.
It can generate C code from the Hybrid automata specification
(written in Python).

Please contact Avinash Malik <avinash.malik@auckland.ac.nz>
for more information.
