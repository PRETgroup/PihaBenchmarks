#ifndef BURNER_STATES_H
#define BURNER_STATES_H

// States
enum burnerStates {b1 , b2 , b3 , b4};

#endif