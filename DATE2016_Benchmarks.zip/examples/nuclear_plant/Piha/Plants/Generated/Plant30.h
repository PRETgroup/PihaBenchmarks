#ifndef PLANT30_H_
#define PLANT30_H_

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include "../../Generic/step.h"
#include "../States.h"

#define NONE 0
#define ADD1 1
#define REMOVE1 2
#define ADD2 3
#define REMOVE2 4

// Plant30 Data Struct
typedef struct {
	// State
	enum plantStates state;
	
	// Inputs
	char control;
	
	// Outputs
	double x;
} Plant30;

// Initialization function
void Plant30Init(Plant30* me);

// Execution function
void Plant30Run(Plant30* me);

#endif // PLANT30_H_
