#ifndef PLANT_STATES_H
#define PLANT_STATES_H

// States
enum plantStates {p1 , p2 , p3};

#endif