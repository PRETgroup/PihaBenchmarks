#ifndef CONTROLLER_STATES_H
#define CONTROLLER_STATES_H

// States
enum controllerStates {t1 , t2 , t3};

#endif