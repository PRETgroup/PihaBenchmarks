#ifndef CONTROLLER17_H_
#define CONTROLLER17_H_

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include "../../Generic/step.h"
#include "../States.h"

#define NONE 0
#define ADD1 1
#define REMOVE1 2
#define ADD2 3
#define REMOVE2 4

// Controller17 Data Struct
typedef struct {
	// State
	enum controllerStates state;
	
	// Inputs
	double x;
	
	// Outputs
	char control;
	
	// Internal Variables
	double y1;
	double y2;
} Controller17;

// Initialization function
void Controller17Init(Controller17* me);

// Execution function
void Controller17Run(Controller17* me);

#endif // CONTROLLER17_H_
