#ifndef CONTROLLER4_H_
#define CONTROLLER4_H_

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include "../../Generic/step.h"
#include "../States.h"

#define NONE 0
#define ADD1 1
#define REMOVE1 2
#define ADD2 3
#define REMOVE2 4

// Controller4 Data Struct
typedef struct {
	// State
	enum controllerStates state;
	
	// Inputs
	double x;
	
	// Outputs
	char control;
	
	// Internal Variables
	double y1;
	double y2;
} Controller4;

// Initialization function
void Controller4Init(Controller4* me);

// Execution function
void Controller4Run(Controller4* me);

#endif // CONTROLLER4_H_
