#ifndef CONTROLLER16_H_
#define CONTROLLER16_H_

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include "../../Generic/step.h"
#include "../States.h"

#define NONE 0
#define ADD1 1
#define REMOVE1 2
#define ADD2 3
#define REMOVE2 4

// Controller16 Data Struct
typedef struct {
	// State
	enum controllerStates state;
	
	// Inputs
	double x;
	
	// Outputs
	char control;
	
	// Internal Variables
	double y1;
	double y2;
} Controller16;

// Initialization function
void Controller16Init(Controller16* me);

// Execution function
void Controller16Run(Controller16* me);

#endif // CONTROLLER16_H_
