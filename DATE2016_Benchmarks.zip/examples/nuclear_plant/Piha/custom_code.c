//fprintf(fo, "%f, %f, %d\n", i*STEP_SIZE, Plant1_data.x, Controller1_data.control);
//fflush(fo);

Plant1_data.control = Controller1_data.control;
Controller1_data.x = Plant1_data.x;

Plant2_data.control = Controller2_data.control;
Controller2_data.x = Plant2_data.x;

Plant3_data.control = Controller3_data.control;
Controller3_data.x = Plant3_data.x;

Plant4_data.control = Controller4_data.control;
Controller4_data.x = Plant4_data.x;

Plant5_data.control = Controller5_data.control;
Controller5_data.x = Plant5_data.x;

Plant6_data.control = Controller6_data.control;
Controller6_data.x = Plant6_data.x;

Plant7_data.control = Controller7_data.control;
Controller7_data.x = Plant7_data.x;

Plant8_data.control = Controller8_data.control;
Controller8_data.x = Plant8_data.x;

Plant9_data.control = Controller9_data.control;
Controller9_data.x = Plant9_data.x;

Plant10_data.control = Controller10_data.control;
Controller10_data.x = Plant10_data.x;

Plant11_data.control = Controller11_data.control;
Controller11_data.x = Plant11_data.x;

Plant12_data.control = Controller12_data.control;
Controller12_data.x = Plant12_data.x;

Plant13_data.control = Controller13_data.control;
Controller13_data.x = Plant13_data.x;

Plant14_data.control = Controller14_data.control;
Controller14_data.x = Plant14_data.x;

Plant15_data.control = Controller15_data.control;
Controller15_data.x = Plant15_data.x;