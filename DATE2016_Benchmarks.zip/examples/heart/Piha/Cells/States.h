#ifndef CELL_STATES_H
#define CELL_STATES_H

// States
enum cellStates {t1 , t2 , t3 , t4};

#endif