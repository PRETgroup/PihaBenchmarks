#ifndef GATE_STATES_H
#define GATE_STATES_H

// States
enum gateStates {g1 , g2};

#endif