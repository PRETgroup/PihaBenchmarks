#ifndef TRAIN_STATES_H
#define TRAIN_STATES_H

// States
enum trainStates {t1 , t2 , t3};

#endif