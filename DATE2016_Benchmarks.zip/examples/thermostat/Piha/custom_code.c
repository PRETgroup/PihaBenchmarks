//fprintf(fo, "%f, %f\n", i*STEP_SIZE, Thermostat1_data.t);
//fflush(fo);