#ifndef THERMOSTAT_STATES_H
#define THERMOSTAT_STATES_H

// States
enum thermostatStates {t1 , t2};

#endif